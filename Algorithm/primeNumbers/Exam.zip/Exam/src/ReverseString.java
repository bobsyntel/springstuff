public class ReverseString {
    public static void main(String[] args){
        System.out.println(reverse("ma")) ;
    }
    static String reverse(String str){
        String rev = "";

        for(int i = str.length()-1;i >= 0;i--){
            rev+=str.charAt(i);
        }
        return rev;

    }
}
